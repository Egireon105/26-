player = {
    "name": "Мегуми",
    "rank": "B",
    "technique": "Тени",
    "HP": 85,
    "accuracy": 87.5
}

print(f"Имя: {player["name"]}")
print(f"Ранг: {player["rank"]}")
print(f"Техника: {player["technique"]}")
print(f"HP: {player["HP"]}")
print(f"Точность: {player["accuracy"]}")

player["HP"] = 60

print(f"После боя HP: {player["HP"]}")