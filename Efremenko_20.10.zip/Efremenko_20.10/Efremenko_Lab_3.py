n = int(input("Введи число: "))
if n % 2 == 0:
    print("Число чётное")
else:
    print("Число нечётное")
