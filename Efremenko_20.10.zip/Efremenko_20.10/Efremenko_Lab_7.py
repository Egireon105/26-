age = int(input("Возраст? "))
power = float(input("Проклятая энергия? "))

print("Полный доступ: ", age >= 16 and power > 100)

print("Временный пропуск: ", age >= 16 or power > 100)

print("В комнату новичков: ", age < 16)