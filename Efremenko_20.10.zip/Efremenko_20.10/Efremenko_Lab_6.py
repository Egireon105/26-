inventory = ["меч", "зелье", "броня", "карта"]

print(f"Предметов: {len(inventory)}")
print(f"Первый: {inventory[0]}")
print(f"Последний: {inventory[-1]}")

inventory.append("снеки")
print(f"После добавления: {inventory}")

inventory[0] = "кирка"
print(f"После замены: {inventory}")