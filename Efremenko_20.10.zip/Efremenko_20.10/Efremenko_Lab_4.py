money = int(input("Сколько рублей в кошельке? "))
crystals = int(money // 7.5)
cache = round(money - crystals * 7.5, 1)


print("Сколько рублей в кошельке?", money)