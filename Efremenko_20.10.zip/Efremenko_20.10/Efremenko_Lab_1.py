name = input("Твоё имя: ")
age = int(input("Возраст: "))
magic = input("Любимая техника: ")

print(name)
print(age)
print(magic)